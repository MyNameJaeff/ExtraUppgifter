const inputBtn = document.getElementById("input-btn");
let savedLinks = ["LINK"];
const inputEl = document.getElementById("input-el");
const unorderedList = document.getElementById("ul-el");

inputBtn.addEventListener(
  "click",
  (savePressed2 = () => {
    savedLinks.push(inputEl.value);
    inputEl.value = "";
    renderLeads();
  })
);

const renderLeads = () => {
  let listItems = "";
  for (let i = 0; i < savedLinks.length; i++) {
    listItems += `<li> <a target='_blank' href='${savedLinks[i]}'>${savedLinks[i]}</a> </li>`;
  }
  unorderedList.innerHTML = listItems;
};
